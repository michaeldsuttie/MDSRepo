﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PISDK;
using System.Threading;

namespace AutoDeleteDuplicatePIValues
{
    class Program
    {
        public static string workingDir { get; set; }
        public static string piServerName { get; set; }
        public static string starttime { get; set; }
        public static string endtime { get; set; }
        public static PIPoint piPoint { get; set; }
        public static List<string> TagList { get; set; }
        public static StringBuilder Messages { get; set; }

        static void Main(string[] args)
        {
            Messages = new StringBuilder();

            string workingDir = $"{AppDomain.CurrentDomain.BaseDirectory}tagList.csv";
            TagList = new List<string>();

            parseCSVtoList(workingDir);

            WriteToLogs($"Working Directory: {workingDir}");
            WriteToLogs($"PI Server: {piServerName}");
            WriteToLogs($"Start Time: {starttime}");
            WriteToLogs($"End Time: {endtime}");

            foreach (var tag in TagList) WriteToLogs($"Will process tag: {tag}");
            if (PromptUser("remove duplicate values", "enter"))
            {
                RemoveDuplicateValues();
                if (PromptUser("exit app", "escape"))
                {
                    WriteSBToFile(Messages);
                    Environment.Exit(-1);
                }
            }
            else if (PromptUser("remove all values", "enter"))
            {
                RemoveAllValues();
                if (PromptUser("exit app", "escape"))
                {
                    WriteSBToFile(Messages);
                    Environment.Exit(-1);
                }
            }
            PromptUser("exit app", "any key");
            WriteSBToFile(Messages);
        }

        public static void RemoveDuplicateValues()
        {
            int tagCount = TagList.Count();
            int currentTagNum = 1;

            foreach (var tag in TagList)
            {
                WriteToLogs($"Tag {currentTagNum} of {tagCount} | Tag: {tag} | Checking for duplicates.");
                int TotalEventsDeleted = 0;

                var piValues = getPIValues(tag);
                if (piValues == null) continue;




                int valueCount = piValues.Count;
                int currentValueNum = 1;

                PIValue previousValue = null;
                foreach (PIValue currentValue in piValues)
                {
                    TotalEventsDeleted = 0;
                    if (previousValue == null)
                    {
                        previousValue = currentValue;
                        //WriteToLogs($"Tag {currentTagNum} of {tagCount} | Value {currentValueNum} of {valueCount} | KEPT VALUE {currentValueNum}: {previousValue.TimeStamp.LocalDate.ToString("dd-MMM-yyyy HH:mm:ss")} {previousValue.Value.ToString()}");
                        //currentValueNum++;
                        continue;
                    }
                    else if (Math.Floor(currentValue.TimeStamp.UTCSeconds) == Math.Floor(previousValue.TimeStamp.UTCSeconds))
                    {
                        if (currentValue.Value == previousValue.Value)
                        {
                            try
                            {
                                piPoint.Data.RemoveValues(currentValue.TimeStamp.UTCSeconds, currentValue.TimeStamp.UTCSeconds, DataRemovalConstants.drRemoveFirstOnly);
                                WriteToLogs($"Tag {currentTagNum} of {tagCount} | KEPT: {previousValue.TimeStamp.LocalDate.ToString("dd-MMM-yyyy HH:mm:ss:ms")} {previousValue.Value} | REMOVED: {currentValue.TimeStamp.LocalDate.ToString("dd-MMM-yyyy HH:mm:ss:ms")} {currentValue.Value}");
                                currentValueNum++;
                                TotalEventsDeleted++;
                                continue;
                            }
                            catch (Exception EX_RemoveDuplicateValues)
                            {
                                WriteToLogs($"Tag: {tag} | Error Deleting Value. {EX_RemoveDuplicateValues.ToString()}");
                                currentValueNum++;
                            }
                        }
                        currentValueNum++;
                    }
                    else
                    {
                        //WriteToLogs($"Tag {currentTagNum} of {tagCount} | Value {currentValueNum} of {valueCount} | KEPT: {previousValue.TimeStamp.LocalDate.ToString("dd-MMM-yyyy HH:mm:ss")} {previousValue.Value.ToString()}");
                        previousValue = currentValue;
                        currentValueNum++;
                    }
                }
                if (TotalEventsDeleted == 0) WriteToLogs($"Tag: {tag} | No Duplicate Events Found.");
                else WriteToLogs($"Tag: {tag} | Duplicate Values Deleted: {TotalEventsDeleted}");
                currentTagNum++;
            }
        }

        public static void RemoveAllValues()
        {
            int tagCount = TagList.Count();
            int currentTagNum = 1;

            foreach (var tag in TagList)
            {
                WriteToLogs($"Tag: {tag} | Clearing All Values");
                int TotalEventsDeleted = 0;

                var piValues = getPIValues(tag);
                if (piValues == null) continue;

                int valueCount = piValues.Count;
                int currentValueNum = 1;

                foreach (PIValue value in piValues)
                {
                    WriteToLogs($"Tag {currentTagNum} of {tagCount} | Value {currentValueNum} of {valueCount} | {value.TimeStamp.LocalDate.ToString()}: {value.Value.ToString()}");
                    try
                    {
                        piPoint.Data.RemoveValues(value.TimeStamp.UTCSeconds, value.TimeStamp.UTCSeconds, DataRemovalConstants.drRemoveFirstOnly);
                    }
                    catch (Exception EX_RemoveAllValues)
                    {
                        WriteToLogs($"Tag: {tag} | Error Deleting Value. {EX_RemoveAllValues.ToString()}");
                    }
                    currentValueNum++;
                    TotalEventsDeleted++;
                }

                if (TotalEventsDeleted == 0) WriteToLogs($"Tag: {tag} | No Events Found.");
                else WriteToLogs($"Tag: {tag} | Events Deleted: {TotalEventsDeleted}");
                currentTagNum++;
            }
        }

        public static void parseCSVtoList(string path)
        {
            TagList.Clear();

            using (StreamReader readFile = new StreamReader(path))
            {
                string line;
                string[] row;
                int rowCount = 0;

                while ((line = readFile.ReadLine()) != null)
                {
                    row = line.Split(',');
                    if (row[0].ToLower().Contains("x")) TagList.Add(row[1]);
                    else if (row[0].ToLower().Contains("starttime")) starttime = DateTime.Parse(row[1]).ToString("dd-MMM-yyyy hh:mm:ss");
                    else if (row[0].ToLower().Contains("endtime")) endtime = DateTime.Parse(row[1]).ToString("dd-MMM-yyyy hh:mm:ss");
                    else if (row[0].ToLower().Contains("piserver")) piServerName = row[1];
                    else if (row[0].ToLower().Contains("workingdirectory")) workingDir = row[1];
                    rowCount += 1;
                }
            }
        }

        private static PIValues getPIValues(string tag)
        {
            PISDK.PISDK sdk = new PISDK.PISDK();
            Server piServer = sdk.Servers[piServerName];
            PIValues _piValues;

            try
            {
                piPoint = piServer.PIPoints[tag];
            }
            catch
            {
                WriteToLogs($"Tag: {tag} | Not Found.");
                return null;
            }

            try
            {
                piPoint = piServer.PIPoints[tag];
                _piValues = piPoint.Data.RecordedValues(starttime, endtime, BoundaryTypeConstants.btInside);

                foreach (PIValue v in _piValues)
                {
                    WriteToLogs($"{v.TimeStamp} | {v.Value}",true);
                }
                return _piValues;
            }
            catch (Exception EX_getPIValues)
            {
                WriteToLogs($"There was an error collecting archived data from PI Server: {piServerName}. {EX_getPIValues.ToString()}");
            }
            return null;
        }

        private static void WriteSBToFile(StringBuilder sb)
        {
            string fileName = "Log";
            string filePathBase = AppDomain.CurrentDomain.BaseDirectory;
            if (!Directory.Exists(filePathBase)) Directory.CreateDirectory(filePathBase);
            string filePath = $"{filePathBase}{fileName}";

            var FilePathFormat = filePath + "{0}";
            int i = 1;
            while (File.Exists($"{filePath}.csv")) filePath = string.Format(FilePathFormat, $"({(i++)})");

            StreamWriter sw = new StreamWriter(filePath + ".csv", true);
            sw.Write(Messages.ToString());
            sw.Flush();
            sw.Close();
        }

        private static void WriteToLogs(string message, bool suppress = false)
        {
            string m = $"{DateTime.Now}: {message}";
            Messages.AppendLine(m);
            if (suppress) return;
            Console.WriteLine(m);
        }

        private static bool PromptUser(string action, string key)
        {
            ConsoleKey ck = new ConsoleKey();
            switch (key.ToLower())
            {
                case "enter":
                    ck = ConsoleKey.Enter;
                    break;
                case "escape":
                    ck = ConsoleKey.Escape;
                    break;
            }
            WriteToLogs($"Press '{key.ToLower()}' to {action}. Press 'Space' to continue.");
            if (Console.ReadKey(true).Key == ck)
            {
                WriteToLogs($"Are you sure you would like to {action}? Press '{key}' to confirm or press 'space' to continue.");
                return Console.ReadKey(true).Key == ck;
            }
            return false;
        }
    }
}